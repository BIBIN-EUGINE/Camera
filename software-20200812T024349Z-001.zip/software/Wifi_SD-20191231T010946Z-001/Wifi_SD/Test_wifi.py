import requests
import os
import time

def Internet_check():
	response = requests.get('https://google.com')
	return response.status_code

def Save_File(Folder_name,response):
	if os.path.isdir(Folder_name):
		filepath = str(Folder_name) + "/image"
		Folder = os.path.isdir(filepath)
		if Folder == False:
			os.mkdir(filepath)
		timestr = time.strftime("%Y%m%d_%H%M%S.txt")
		filename = str(filepath)+str(timestr)
		f = open(filename,"w+")
		response = str(response)
		f.write(response)
		f.close()
	else:
		print("No SDCard Inserted")

def main():
	IC = Internet_check()
	print(IC)
	if IC:
		Save_File("D:\WORK\IMX\Components\Wifi_SD",IC)


if __name__ == "__main__":
	main()	
	



	